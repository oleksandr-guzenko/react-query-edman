/**
 * @jest-environment jsdom
 */

import Header from "../components/layouts/Header";
import {cleanup, fireEvent, render, screen} from '@testing-library/react';

afterEach(cleanup);

describe('The Header Component', () => {
  test('check image source', () => { 
    const render = 
   })
});
